package com.training.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {
	
public static void main(String arg[]) {
		
		List carSales  = new ArrayList<Integer>();
		
		carSales.add(0,1000);
		carSales.add(1,700);
		carSales.add(2,1200);
		carSales.add(3,500);
		carSales.add(4,600);
		carSales.add(540);
		carSales.add(880);
		
		System.out.println("Random access  No of cars sold: "+carSales.get(4));
		
		for (int i = 0; i< carSales.size(); i++) {
			
			System.out.println("No of cars sold: "+carSales.get(i));
		}
		
		System.out.println();
		System.out.println("After sorting the arraylist");
		System.out.println();
		Collections.sort(carSales);
		
		for (int i = 0; i< carSales.size(); i++) {
			
			System.out.println("No of cars sold: "+carSales.get(i));
		}
				
		
	}

}
