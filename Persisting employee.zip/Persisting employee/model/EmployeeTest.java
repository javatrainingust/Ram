package com.training.model;

import static org.junit.Assert.*;

import org.junit.Test;

public class EmployeeTest {

	@Test
	public void testUpdateLeave() {
		
		int expectedValue = 17;
		
		Employee e = new Employee();
		
		e.updateLeave(3);
		
		int actualValue = e.getLeaves();
		
		assertEquals(expectedValue,actualValue);
		
	}

}
