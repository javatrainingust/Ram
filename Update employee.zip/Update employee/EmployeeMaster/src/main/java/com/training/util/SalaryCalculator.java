package com.training.util;

public class SalaryCalculator  implements CalculatorSalary{
	
	private float pfPercentage=0.12f;
	
	private float taxPercentage = .3f;
	
	private float hraPercentage = .5f;
	
	public float calculateSalary(int lossOfPay,float basic){
		
		
		float hra = basic * hraPercentage;
		
		float lossOfPayAmount = (basic/30) *lossOfPay;
		
		float pf = basic * pfPercentage;
		
		float grossSalary =basic + hra;
		
		//System.out.println("gross "+grossSalary);
		
		float netSalary =grossSalary-(grossSalary *taxPercentage);
		
		//System.out.println("net "+netSalary);
		
		float netSalaryAfterDeduction = netSalary-pf;
		
		//System.out.println("netSalaryAfterDeduction "+netSalaryAfterDeduction);
		
		//System.out.println("lossOfPayAmount "+lossOfPayAmount);
		float takeHomeSalary = netSalaryAfterDeduction-lossOfPayAmount;
		
		return takeHomeSalary;		
		
		
		
	}
	
	public float calculateSalary (int lossOfPay, float dailyRate, int contractPeriodInDays){
		
		float grossSalary = (contractPeriodInDays-lossOfPay) * dailyRate;
		
		float netSalary = grossSalary-(grossSalary * .3f);
		
		
		return netSalary;
	}
	

}
