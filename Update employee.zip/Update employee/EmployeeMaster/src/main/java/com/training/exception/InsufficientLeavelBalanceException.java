package com.training.exception;

public class InsufficientLeavelBalanceException extends Exception{
	
	int leaves;
	
	public InsufficientLeavelBalanceException(int leaves){
		
		this.leaves = leaves;
	}
	
public String toString(){
		
		return "You have not enough leave. You applied for "+leaves+" days";
	}
}
