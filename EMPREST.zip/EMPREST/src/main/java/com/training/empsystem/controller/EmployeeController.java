package com.training.empsystem.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.http.HttpStatus;

import org.springframework.web.bind.annotation.ExceptionHandler;

import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.training.empsystem.model.Employee;

@RestController
public class EmployeeController {
	
	
	Map<Integer,Employee> employeeDatabase = new HashMap<Integer,Employee>();
	
	
	
	
	@RequestMapping(value="/employees/dummy",method=RequestMethod.GET) 
	public Employee getDummyEmployee() {
		
		Employee employee = new Employee();
		
		employee.setId(1000);
		employee.setName("Murugan");
		employee.setMessage("Dummy employee created");
		
		employeeDatabase.put(1000, employee);
		
		return employee;	
		
		
		
	}
	
	@RequestMapping(value="/employees/{id}",method=RequestMethod.GET) 
	public Employee getEmployee(@PathVariable int id) {
		
		Employee  employee = new Employee();
		
		if(employeeDatabase.containsKey(id)) {
			employee = employeeDatabase.get(id);
			employee.setMessage("Employee retrieved");
			
		}
		else {
			employee.setMessage("Employee not found");
			
		}
				
		return employee;
	}
	
	@RequestMapping(value="/employees",method=RequestMethod.GET) 
	public List<Employee> getAllEmployees() {
		
		List<Employee> employees  = new ArrayList<Employee>();
		
		Set<Integer> employeeIdKeys = employeeDatabase.keySet();
		
		for(Integer i: employeeIdKeys) {
			
			employees.add(employeeDatabase.get(i));
		}
			
		
		return employees;	
		
		
		
	}
	
	@RequestMapping(value="/employees",method=RequestMethod.POST) 
	public Employee createEmployee(@RequestBody Employee employee) {
		
		System.out.println("employee id: "+ employee.getId());
		if(employeeDatabase.containsKey(employee.getId())) {
			
			employee.setMessage("Employee already exist");
			
		}
		else {
			
			employeeDatabase.put(employee.getId(), employee);
			employee.setMessage("Employee created");
			
		}
				
		return employee;
		
		
	}
	
	@RequestMapping(value="/employees/{id}",method=RequestMethod.DELETE)
	public Employee deleteEmployee(@PathVariable int id) {
		
		Employee  employee = new Employee();
		
		if(employeeDatabase.containsKey(id)) {
			employee = employeeDatabase.get(id);
			
			employeeDatabase.remove(id);
			
			employee.setMessage("Employee deleted");
			
		}
		else {
			
			employee.setMessage("Employee not found");
			
		}
				
		return employee;
		
		
		
	}
	
	@RequestMapping(value="/employees/{id}",method=RequestMethod.PUT)
	public Employee updateEmployee(@PathVariable int id,@RequestBody Employee Modifiedemployee ) {
		
		Employee  employee = new Employee();
		
		if(employeeDatabase.containsKey(id)) {
			
			employee = employeeDatabase.get(id);
			employee.setName(Modifiedemployee.getName());
			
			employee.setMessage("Employee updated");
			
		}
		else {
			employee.setMessage("Employee not found");
			
		}
				
		return employee;
	}
	
	
}
