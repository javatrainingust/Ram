package com.training;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Main {
	
public static void main(String arg[]) {
		
		
		List cars = new ArrayList<Car>();
		
		Car car1 = new Car("TN22BB5544","Honda","City");
		
		Car car2 = new Car("PY22BB5544","Maruti","Swift");
		
		Car car3 = new Car("KL22BB5544","Hyundai","i20");
		
		cars.add(car1);
		cars.add(car2);
		cars.add(car3);
		
		Iterator<Car> i1 =cars.iterator();
		
		while(i1.hasNext()){
			
			Car c = i1.next();
			System.out.println("Car : "+c);
		}
		
		Collections.sort(cars);
		
		System.out.println("Afte sorting based on albhabetical order of brand");
		
Iterator<Car> i2 =cars.iterator();
		
		while(i2.hasNext()){
			
			Car c = i2.next();
			System.out.println("Car : "+c);
		}
	}

}
