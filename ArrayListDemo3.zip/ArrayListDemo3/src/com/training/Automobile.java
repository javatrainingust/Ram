package com.training;


public interface Automobile {
	
		
	public void applyBrake();
	
	public void applyAccelarate();
}
