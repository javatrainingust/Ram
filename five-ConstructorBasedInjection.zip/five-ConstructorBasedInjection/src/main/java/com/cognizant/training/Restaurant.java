package com.cognizant.training;


public class Restaurant {
	
	GroceriesShop GopalProvisionsStore;
	
	VegetableShop MuruganVegetableMart;
	
	public Restaurant() {
		
		System.out.println("inside default constructor of Restaurant");
	}
	
	public Restaurant(GroceriesShop groceriesShop, VegetableShop vegetableShop) {
		
		System.out.println("inside parameterarized constructor of Restaurant");
		GopalProvisionsStore = groceriesShop;
		
		MuruganVegetableMart = vegetableShop;
		
		
	}
	
	
	public void prepareMeal() {
		
		
		
		GopalProvisionsStore.supplyGroceries();
		
		MuruganVegetableMart.supplyVegetables();
		
		System.out.println("Meals is prepared");
	}
	
	
	public void serveMeal() {
		
		prepareMeal();
		System.out.println("Meal is served");
		
	}
	
	
	
	
	
}
