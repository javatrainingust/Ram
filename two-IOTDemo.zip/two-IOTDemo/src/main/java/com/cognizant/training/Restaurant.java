package com.cognizant.training;


public class Restaurant {
	
	
	public Restaurant() {
		
		System.out.println("inside default constructor of Restaurant");
		
	}
	
	public void serveMeal() {
		
		System.out.println("Meal is served");
		
	}
	
	
	
	
	
}
