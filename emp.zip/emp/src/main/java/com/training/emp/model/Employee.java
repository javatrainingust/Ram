/**
 * Classname:Employee
 * 
 * Description:This is a base class for employee sub types
 *
 * Date:09/30/2020
 * 
*/

package com.training.emp.model;

import java.io.FileNotFoundException;

import com.training.emp.exception.InsufficientLeavelBalanceException;
import com.training.emp.util.CalculatorSalary;
import com.training.emp.util.SalaryCalculator;

/**
*This class is used to model the employee of organization
*/

public class Employee {
	
	/*@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + employeeId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (employeeId != other.employeeId)
			return false;
		return true;
	}*/

	private int employeeId;
	
	protected String name;
	
	private int leaves=20;
		
	protected float  takeHomeSalary;
	
	/**
	*Employee no-arg constructor
	*/

	public Employee(){
		
		System.out.println("Inside Employee no org constructor");
	}
	
	/**
	*Employee parameterized constructor
	*/
	public Employee(int id,String name){
		
		//System.out.println("Inside Employee parameterized constructor");
		
		this.employeeId=id;
		
		this.name=name;
		
	}
	
	/**
	*Accessor method for takeHomeSalary
	*/
	public float getTakeHomeSalary() {
		return takeHomeSalary;
	}


	/**
	*Accessory method for takeHomeSalary
	*/
	public void setTakeHomeSalary(float takeHomeSalary) {
		this.takeHomeSalary = takeHomeSalary;
	}


	/**
	*Accessor method for employeeId
	*/
	public int getEmployeeId() {
		return employeeId;
	}


	/**
	*Accessor method for employeeId
	*/
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}


	/**
	*Accessor method for name
	*/
	public String getName() {
		return name;
	}


	/**
	*Accessor method for name
	*/
	public void setName(String name) {
		this.name = name;
	}

	/**
	*Accessor method for leaves
	*/
	public int getLeaves() {
		return leaves;
	}


	/**
	*This method is called by the leave management system when the employee applies for the leave.
	*/
	public void applyLeave(int leaveApplied) throws InsufficientLeavelBalanceException{
		
		if (leaveApplied > this.leaves) {
			
			throw new InsufficientLeavelBalanceException(leaveApplied);
		}
		else {
		this.leaves = this.leaves-leaveApplied;
		
		System.out.println("Availabe leaves "+ this.leaves);
		}
		
	}
	
	/**
	*This method is called by the Pay roll system to calculate the salary of employee
	*/
	public  void  calculateSalary(int lossOfPay,CalculatorSalary calculator) {
		
		System.out.println("inside employee class");
		
		
	}

}
