package com.training.emp.dataaccess;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.training.emp.model.ContractEmployee;

public class ContractEmployeeDAOImpl implements ContractEmployeeDAO {
	
	List contractEmployeeList;
	
	public ContractEmployeeDAOImpl(){
		
		contractEmployeeList = new ArrayList<ContractEmployee>();
		
		ContractEmployee ce1 = new ContractEmployee(5000, "Guna",20, 4000);	
		
		ContractEmployee ce2 = new ContractEmployee(5001, "Anand",20, 5000);
		
		
		ContractEmployee ce3 = new ContractEmployee(5002, "Ravi",20, 7000);
		
		ContractEmployee ce4 = new ContractEmployee(5003, "Yuvaraj",20, 3000);
		
		ContractEmployee ce5 = new ContractEmployee(5004, "Mano",20, 4000);
		
		contractEmployeeList.add(ce1);
		
		contractEmployeeList.add(ce2);
		
		contractEmployeeList.add(ce3);
		
		contractEmployeeList.add(ce4);
		
		contractEmployeeList.add(ce5);
		
	}
	
	

	
	public List<ContractEmployee> getAllContractEmployees() {
		// TODO Auto-generated method stub
		return contractEmployeeList;
	}


	public ContractEmployee getContractEmployeeByEmployeeId(int employeeId) {
		
		ContractEmployee contractEmployee =null;
		
		Iterator<ContractEmployee>   iterator = contractEmployeeList.iterator();
		
		while(iterator.hasNext()){
			
			ContractEmployee ce = iterator.next();
			
			if(ce.getEmployeeId()==employeeId){
				
				contractEmployee=ce;
				
			}
			
			
		}
				
		
		
		return contractEmployee;
	}

	
	public void deleteContractEmployee(int employeeId) {
		
		
		for(int i=0; i< contractEmployeeList.size(); i++){
			
			ContractEmployee ce =(ContractEmployee)contractEmployeeList.get(i);
			
			if(ce.getEmployeeId()==employeeId){
				
				contractEmployeeList.remove(i);
				
			}
			
			
		}

	}

	
	public boolean addContractEmployee(ContractEmployee contractEmployee) {
		// TODO Auto-generated method stub
		return false;
	}

	
	public void updateContractEmployee(ContractEmployee contractEmployee) {
		// TODO Auto-generated method stub

	}

}
