package com.training.emp.model;

import static org.junit.Assert.*;

import org.junit.Test;

public class EmployeeTest {

	@Test
	public void testUpdateLeave() {
		
		int expectedValue = 17;
		
		Employee e = new Employee();
		try{
		e.applyLeave(3);
		}
		catch(Exception exception){}
		int actualValue = e.getLeaves();
		
		assertEquals(expectedValue,actualValue);
		
	}

}
