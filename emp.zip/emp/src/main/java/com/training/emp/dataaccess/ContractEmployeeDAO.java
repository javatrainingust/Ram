package com.training.emp.dataaccess;

import java.util.List;

import com.training.emp.model.ContractEmployee;

public interface ContractEmployeeDAO {
	
public List<ContractEmployee> getAllContractEmployees();
	
	public ContractEmployee getContractEmployeeByEmployeeId(int employeeId);
	
	public void deleteContractEmployee(int employeeId);
	
	public boolean addContractEmployee(ContractEmployee contractEmployee);
	
	public void updateContractEmployee(ContractEmployee contractEmployee);
	
	

}
