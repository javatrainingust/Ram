package com.training.emp.service;

import com.training.emp.model.PermanentEmployee;

public class PermanentEmployeeAddDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		PermanentEmployeeService service = new PermanentEmployeeService();
		
		
		service.addPermanentEmployee(new PermanentEmployee(1000,"Ram", "Developer",50000));
		
		service.addPermanentEmployee(new PermanentEmployee(1001,"Vivek", "Tech Lead",70000));
		
		service.addPermanentEmployee(new PermanentEmployee(1001,"Vivek", "Tech Lead",70000));
		
		System.out.println("Printing all employees");	
		service.getAllPermanentEmployees();
		System.out.println("---------------------------------------------");	
		/*service.updatePermanentEmployee(new PermanentEmployee(1001,"Vivek", "Project Lead",100000));
		
		System.out.println("Printing all updated employees");	
		
		service.getAllPermanentEmployees();*/
	}

}
