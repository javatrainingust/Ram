package com.training.emp.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.training.emp.dataaccess.PermanentEmployeeDAO;
import com.training.emp.dataaccess.PermenantEmployeeDAOImpl;
import com.training.emp.model.PermanentEmployee;

@Service
public class PermanentEmployeeService {

@Autowired	
private PermanentEmployeeDAO permanentEmployeeDAOImpl;
	
	public PermanentEmployeeService(){
		
		
		
	} 
	
	
	public List<PermanentEmployee> getAllPermanentEmployees() {
		
		System.out.println("Inside service");
		
		
		List permanentEmployeeList = permanentEmployeeDAOImpl.getAllPermanentEmployees();
		
		
		/*
		 * Iterator<PermanentEmployee> iterator = permanentEmployeeList.iterator();
		 * 
		 * while(iterator.hasNext()){
		 * 
		 * PermanentEmployee pe = iterator.next();
		 * 
		 * System.out.println("Employee Id "+pe.getEmployeeId());
		 * System.out.println("Employee name "+pe.getName());
		 * System.out.println("Employee designation "+pe.getDesignation());
		 * System.out.println("Employee basic salary "+pe.getBasicSalary());
		 * 
		 * }
		 */
			
		return permanentEmployeeList;
		
		
		
	}
	
	
	
	public PermanentEmployee getPermanentEmployeeByEmployeeId(int employeeId) {
		
		
		
		
		PermanentEmployee pe = permanentEmployeeDAOImpl.getPermanentEmployeeByEmployeeId(employeeId);
		
		
		System.out.println("Employee Id "+pe.getEmployeeId());
		System.out.println("Employee name "+pe.getName());
		System.out.println("Employee designation "+pe.getDesignation());
		System.out.println("Employee basic salary "+pe.getBasicSalary());
		
		return pe;
		
		
		
		
	}
		
		
	public void deletePermanentEmployee(int employeeId) {
		
		
		
		
		permanentEmployeeDAOImpl.deletePermanentEmployee(employeeId);
		
	}	
		
		
		
		
	public List<PermanentEmployee>	getAllPermanentEmployeesSortedByNames(){
		
		
		List<PermanentEmployee> permanentEmployeeList = permanentEmployeeDAOImpl.getAllPermanentEmployees();
		
		//Collections.sort(permanentEmployeeList);
		
		Stream<PermanentEmployee> permanentEmployeeStream = permanentEmployeeList.stream();
		
		Stream<PermanentEmployee> sortedStream = permanentEmployeeStream.sorted();
		
		List sortedPermenantEmployeeList = sortedStream.collect(Collectors.toList());
		
		
		Iterator<PermanentEmployee> iterator = sortedPermenantEmployeeList.iterator();
		
		while(iterator.hasNext()){
			
			PermanentEmployee pe = iterator.next();
			
			System.out.println("Employee Id "+pe.getEmployeeId());
			System.out.println("Employee name "+pe.getName());
			System.out.println("Employee designation "+pe.getDesignation());
			System.out.println("Employee basic salary "+pe.getBasicSalary());
			
			}			
		
		
		
		return sortedPermenantEmployeeList;
	}
	
	
	
public List<PermanentEmployee>	getAllPermanentEmployeesSortedByBasicSalary(){
		
		
		List<PermanentEmployee> permanentEmployeeList = permanentEmployeeDAOImpl.getAllPermanentEmployees();
		
		//Collections.sort(permanentEmployeeList,new SalaryComparator());
		
		Stream<PermanentEmployee> permanentEmployeeStream = permanentEmployeeList.stream();
		
		Stream<PermanentEmployee> sortedStream = permanentEmployeeStream.sorted(new SalaryComparator());
		
		List sortedPermenantEmployeeList = sortedStream.collect(Collectors.toList());
		
		
		Iterator<PermanentEmployee> iterator = sortedPermenantEmployeeList.iterator();
		
		while(iterator.hasNext()){
			
			PermanentEmployee pe = iterator.next();
			
			System.out.println("Employee Id "+pe.getEmployeeId());
			System.out.println("Employee name "+pe.getName());
			System.out.println("Employee designation "+pe.getDesignation());
			System.out.println("Employee basic salary "+pe.getBasicSalary());
			
			}			
		
		
		
		return sortedPermenantEmployeeList;
	}
		
public void addPermanentEmployee(PermanentEmployee permanentEmployee) {
	
	boolean isAdded = permanentEmployeeDAOImpl.addPermanentEmployee(permanentEmployee);
	
	if(!isAdded){
		
		System.out.println("The employee already exist");
	}
	else{
		System.out.println("The employee successfully added");
		
	}
	
}
		
public void updatePermanentEmployee(PermanentEmployee permanentEmployee){
	
	permanentEmployeeDAOImpl.updatePermanentEmployee(permanentEmployee);
}

}
