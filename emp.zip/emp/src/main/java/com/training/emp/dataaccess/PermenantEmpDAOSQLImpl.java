package com.training.emp.dataaccess;

import java.util.List;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.training.emp.model.PermanentEmployee;

@Repository
public class PermenantEmpDAOSQLImpl implements PermanentEmployeeDAO {
	
	
private DataSource dataSource;

private JdbcTemplate jdbcTemplateObject;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplateObject = new JdbcTemplate(dataSource);
	}

	
	

	public List<PermanentEmployee> getAllPermanentEmployees() {
		
		String SQL = "select * from employee";
	      List <PermanentEmployee> employees= jdbcTemplateObject.query(SQL, new EmployeeMapper());
		
		return employees;
	}

	public PermanentEmployee getPermanentEmployeeByEmployeeId(int employeeId) {
		String sql = "SELECT * FROM EMPLOYEE WHERE ID = ?";
		 
		PermanentEmployee employee = (PermanentEmployee) jdbcTemplateObject.queryForObject(
                sql, new Object[] { employeeId }, new EmployeeMapper());
      
       return 	employee;	
	}

	public void deletePermanentEmployee(int employeeId) {
		 String query="delete from employee where id='"+employeeId+"' ";  
		 jdbcTemplateObject.update(query);  

	}

	public boolean addPermanentEmployee(PermanentEmployee permanentEmployee) {
		String sql = "INSERT INTO EMPLOYEE " +
	            "(ID, NAME, DESIGN,LEAVES,BASIC,TAKEHOME) VALUES (?, ?, ?,?,?,?)";
	  
	        
	  
		jdbcTemplateObject.update(sql, new Object[] { permanentEmployee.getEmployeeId(),
				permanentEmployee.getName(), permanentEmployee.getDesignation(),permanentEmployee.getLeaves(),permanentEmployee.getBasicSalary(),permanentEmployee.getTakeHomeSalary() 
	        });
		return true;
	}

	public void updatePermanentEmployee(PermanentEmployee permanentEmployee) {
		String query="update employee set  name='"+permanentEmployee.getName()+"',basic='"+permanentEmployee.getBasicSalary()+"' where id='"+permanentEmployee.getEmployeeId()+"' ";  
	    jdbcTemplateObject.update(query);  


	}

}
