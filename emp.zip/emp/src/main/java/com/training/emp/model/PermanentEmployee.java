package com.training.emp.model;

import java.io.FileNotFoundException;

import com.training.emp.util.CalculatorSalary;
import com.training.emp.util.SalaryCalculator;

public class PermanentEmployee extends Employee  implements Appraisable,Comparable<PermanentEmployee>{
	
	private int rating;
	
	public int getRating() {
		return rating;
	}

	private String designation;
	
	private float basicSalary;
	
	public PermanentEmployee(){
		
		System.out.println("Inside PermanentEmployee no org constructor");
	}
	
	public PermanentEmployee(int id,String name, String desgn,float basic){
		super(id,name);
		//System.out.println("Inside PermanentEmployee parameterized constructor");
		
		this.designation=desgn;
		this.basicSalary=basic;
	}
	
	public float getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(float basicSalary) {
		this.basicSalary = basicSalary;
	}

	
	
	
	
	public String getDesignation() {
		return designation;
	}



	public void setDesignation(String designation) {
		this.designation = designation;
	}

public void calculateSalary(int lossOfPay,CalculatorSalary calculator) {
		
		System.out.println("inside permanent employee class");
		
		//call the salarycalculator calculateSalary method
		this.takeHomeSalary=calculator.calculateSalary(lossOfPay, basicSalary);
		
		System.out.println("Take home salary ="+this.takeHomeSalary);
		
		
		
	}


public void doPerformanceAppraisal(String feedback) {

	//for excellent set rating as 1
	if(feedback.equals("Excellent")){
		
		this.rating =1;
	}
	else if(feedback.equals("better")){
		this.rating = 2;
		
	}
	else if(feedback.equals("good")){
		
		this.rating=3;
		
	}
	else if(feedback.equals("Average")){
		
		this.rating=4;
	}
	
	System.out.println("Rating is "+this.rating);
	
}


public int compareTo(PermanentEmployee pe) {
	
	return this.name.compareTo(pe.getName());
}


}
