package com.training.emp.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class SalaryCalculatorTest {

	@Test
	public void testCalculateSalaryIntFloat() {
		
		float expectedValue =8966.667f;
		
		SalaryCalculator cal = new SalaryCalculator();
		
		float  actualValue = cal.calculateSalary(1, 10000);
		
		assertEquals(expectedValue,actualValue,0.0f);
		
	}

	@Test
	public void testCalculateSalaryIntFloatInt() {
		
		float expectedValue = 70000f;
		
		
		SalaryCalculator cal = new SalaryCalculator();
		
		float  actualValue = cal.calculateSalary(1, 5000, 21);
		
		assertEquals(expectedValue,actualValue,0.0f);
	}

}
