package com.training.dataaccess;

import java.util.List;

import com.training.model.ContractEmployee;

public interface ContractEmployeeDAO {
	
public List<ContractEmployee> getAllContractEmployees();
	
	public ContractEmployee getContractEmployeeByEmployeeId(int employeeId);
	
	public void deleteContractEmployee(int employeeId);
	
	public boolean addContractEmployee(ContractEmployee contractEmployee);
	
	public void updateContractEmployee(ContractEmployee contractEmployee);
	
	

}
