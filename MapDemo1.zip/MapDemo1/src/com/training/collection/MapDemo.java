package com.training.collection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class MapDemo {
	
	
	public static  void main(String arg[]) {
		
		Map students = new HashMap<String, Integer>();
		
		students.put("Kumar", 85);
		
		students.put("Krishna", 60);
		
		students.put("Ravi", 90);
		
		
		
            System.out.println("Marks of Kumar: " +students.get("Kumar"));
       
		
	}
	

}
