package com.training.service;

public class PermanentEmployeeDeleteDemo {

	public static void main(String[] args) {
		
		PermanentEmployeeService service =  new PermanentEmployeeService();
		
		System.out.println();
		System.out.println("all employees are retrieved");
		
		service.getAllPermanentEmployees();
				
		
		service.deletePermanentEmployee(1002);
		System.out.println("----------------------------------");
		
		System.out.println();
		System.out.println("After deletion");
		
		service.getAllPermanentEmployees();

	}

}
