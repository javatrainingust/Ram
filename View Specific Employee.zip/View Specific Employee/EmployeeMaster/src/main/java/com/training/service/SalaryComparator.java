package com.training.service;
import com.training.model.PermanentEmployee;
import java.util.Comparator;

public class SalaryComparator implements Comparator<PermanentEmployee>{

	
	public int compare(PermanentEmployee one, PermanentEmployee two) {
		// TODO Auto-generated method stub
		return (int) (one.getBasicSalary()-two.getBasicSalary());
	}

}
