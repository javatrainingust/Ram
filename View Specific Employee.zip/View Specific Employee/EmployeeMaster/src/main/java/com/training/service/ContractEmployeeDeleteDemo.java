package com.training.service;

public class ContractEmployeeDeleteDemo {

	public static void main(String[] args) {
		
		
		ContractEmployeeService service = new ContractEmployeeService();
		
		
		System.out.println("Printing all employees");
		
		service.getAllContractEmployees();
		
		
		System.out.println("----------------------------------");
		
		service.deleteContractEmployee(5003);
		
		System.out.println("After deletion");
		
		service.getAllContractEmployees();
		
	}
	

}
