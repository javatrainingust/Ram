package com.training.service;

public class ContractEmployeeRetrivalDemo {

	public static void main(String[] args) {
		
		ContractEmployeeService service  =  new ContractEmployeeService();
		
		System.out.println("Printing all employees");
		
		service.getAllContractEmployees();
		
		System.out.println("--------------------------------");
		
		System.out.println("Printing a specific employee");
		
		service.getContractEmployeeByEmployeeId(5003);
	}

}
