package com.generic.service;

import com.training.model.ContractEmployee;
import com.training.model.Employee;
import com.training.model.PermanentEmployee;
import com.training.repository.EmployeeRepository;
import com.training.util.SalaryCalculator;

public class GeneralService {
	
	public static void main (String arg[]){
		
PermanentEmployee pe = new  PermanentEmployee(1000,"Kumar","Developer",10000);


		
		
		SalaryCalculator calculator = new SalaryCalculator();
		
		pe.calculateSalary(1, calculator);
		
		
		
		
		
	}

}
