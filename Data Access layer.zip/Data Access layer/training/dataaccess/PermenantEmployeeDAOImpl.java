package com.training.dataaccess;

import com.training.model.PermanentEmployee;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.training.model.PermanentEmployee;

public class PermenantEmployeeDAOImpl implements PermanentEmployeeDAO {
	
	List permanentEmployeeList;
	
	public PermenantEmployeeDAOImpl(){
		
		permanentEmployeeList = new ArrayList<PermanentEmployee>();
		
		PermanentEmployee pe1 = new PermanentEmployee(1000,"Ram", "Developer",50000);
		
		PermanentEmployee pe2 = new PermanentEmployee(1001,"Vivek", "Tech Lead",70000);
		
		PermanentEmployee pe3 = new PermanentEmployee(1002,"Komal", "Manager",80000);
		
		PermanentEmployee pe4 = new PermanentEmployee(1003,"Anish", "Analyst",60000);
		
		PermanentEmployee pe5 = new PermanentEmployee(1004,"John", "Tester",40000);
		
		permanentEmployeeList.add(pe1);
		permanentEmployeeList.add(pe2);
		permanentEmployeeList.add(pe3);
		permanentEmployeeList.add(pe4);
		permanentEmployeeList.add(pe5);
		
	}
		
	

	@Override
	public List<PermanentEmployee> getAllPermanentEmployees() {
		
		return permanentEmployeeList;
	}

	@Override
	public PermanentEmployee getPermanentEmployeeByEmployeeId(int employeeId) {
		// TODO Auto-generated method stub
		PermanentEmployee permanentEmployee=null;
		
		Iterator<PermanentEmployee> iterator = permanentEmployeeList.iterator();
		
		while(iterator.hasNext()){
			
			PermanentEmployee pe = iterator.next();
			
			if(pe.getEmployeeId()==employeeId){
				
				permanentEmployee=pe;
			}
			
			
		}
			
		
		return permanentEmployee;
	}

	@Override
	public void deletePermanentEmployee(int employeeId) {
		
		
		
		PermanentEmployee permanentEmployee = null;
		
		for(int i=0; i<permanentEmployeeList.size(); i++){
			
			permanentEmployee =(PermanentEmployee) permanentEmployeeList.get(i);
			
			if(permanentEmployee.getEmployeeId()==employeeId){
				
				permanentEmployeeList.remove(i);
				
			}
			
		}		
		
		

	}

	@Override
	public boolean addPermanentEmployee(PermanentEmployee permanentEmployee) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void updatePermanentEmployee(PermanentEmployee permanentEmployee) {
		// TODO Auto-generated method stub

	}

}
