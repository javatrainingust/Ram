package com.training.service;

import java.util.Iterator;
import java.util.List;

import com.training.dataaccess.ContractEmployeeDAO;
import com.training.dataaccess.ContractEmployeeDAOImpl;
import com.training.model.ContractEmployee;

public class ContractEmployeeService {
	
	
	ContractEmployeeDAO daoImpl;
	
	public ContractEmployeeService(){
		
		
		daoImpl = new ContractEmployeeDAOImpl();
		
		
	}
	
	
	public List<ContractEmployee> getAllContractEmployees() {
		
		
		
		List contractEmployeeList = daoImpl.getAllContractEmployees();
		
		
		
		Iterator<ContractEmployee>   iterator = contractEmployeeList.iterator();
		
			while(iterator.hasNext()){
			
			ContractEmployee ce = iterator.next();
			
			
			System.out.println("Employee Id: "+ce.getEmployeeId());
			System.out.println("Employee name: "+ce.getName());
			System.out.println("Employee contract period: "+ce.getContractPeriodInDays());
			System.out.println("Employee daily rate: "+ce.getDailyRate());
			
				
			}
			
			return contractEmployeeList;
		}
		
		
		
		
		
	public ContractEmployee getContractEmployeeByEmployeeId(int employeeId){
		
		
		ContractEmployee ce = daoImpl.getContractEmployeeByEmployeeId(employeeId);
		
		
		System.out.println("Employee Id: "+ce.getEmployeeId());
		System.out.println("Employee name: "+ce.getName());
		System.out.println("Employee contract period: "+ce.getContractPeriodInDays());
		System.out.println("Employee daily rate: "+ce.getDailyRate());
		
		
		return ce;
		
		
		
	}
		
		
	public void deleteContractEmployee(int employeeId) {
		
		
		
		daoImpl.deleteContractEmployee(employeeId);
		
		
		
		
		
	}	
	

}
