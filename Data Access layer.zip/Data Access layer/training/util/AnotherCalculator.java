package com.training.util;

public class AnotherCalculator implements CalculatorSalary{

	@Override
	public float calculateSalary(int lossOfPay, float basic) {
		
		float gross = basic+20000+30000+10000;
		return gross;
	}

	@Override
	public float calculateSalary(int lossOfPay, float dailyRate, int contractPeriodInDays) {
		// TODO Auto-generated method stub
		return 0;
	}

}
