package com.training.util;

public class NewSalaryCalculator implements CalculatorSalary{

	@Override
	public float calculateSalary(int lossOfPay, float basic) {
		
		float grossSalary = basic+(basic *.5f)+20000f;
		
		return grossSalary;
	}

	@Override
	public float calculateSalary(int lossOfPay, float dailyRate, int contractPeriodInDays) {
		// TODO Auto-generated method stub
		return 0;
	}

}
