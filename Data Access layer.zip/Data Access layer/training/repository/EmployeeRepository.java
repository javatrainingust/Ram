package com.training.repository;

import com.training.model.ContractEmployee;
import com.training.model.Employee;
import com.training.model.PermanentEmployee;

public class EmployeeRepository {
	
	
	public static Employee getPermanentEmployee(){
		
		PermanentEmployee pe = new PermanentEmployee();
		
		return pe;
	}

	
	public static Employee  getContractEmployee(){
		
		ContractEmployee ce = new ContractEmployee();
		
		return ce;
	}
}
