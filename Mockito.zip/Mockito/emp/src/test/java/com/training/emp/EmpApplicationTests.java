package com.training.emp;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.training.emp.service.*;

import com.training.emp.dataaccess.PermanentEmployeeDAO;
import com.training.emp.model.PermanentEmployee;

@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
class EmpApplicationTests {
	
	@Mock
	private PermanentEmployeeDAO PermanentEmployeeDAOMock;
	
	@InjectMocks
	private PermanentEmployeeService service;

	/*
	 * @Test public void getEmployeesBasedOnSalaries() {
	 * 
	 * 
	 * 
	 * assertEquals(1, service.getEmployeesBasedOnSalary(60000).size());
	 * 
	 * }
	 */
	
	@Test 
	  public void testGetAllEmployeesBySalary() {
		
		PermanentEmployee pe1 = new PermanentEmployee();
		pe1.setBasicSalary(50000);
		
		PermanentEmployee pe2 = new PermanentEmployee();
		pe2.setBasicSalary(40000);
		
		PermanentEmployee pe3 = new PermanentEmployee();
		pe3.setBasicSalary(80000);
		
		PermanentEmployee pe4 = new PermanentEmployee();
		pe4.setBasicSalary(20000);
		
		PermanentEmployee pe5 = new PermanentEmployee();
		pe5.setBasicSalary(10000);
		
		List<PermanentEmployee> employees = new ArrayList();
		
		employees.add(pe1);
		employees.add(pe2);
		employees.add(pe3);
		employees.add(pe4);		
		employees.add(pe5);
		
		
		when(PermanentEmployeeDAOMock.getAllPermanentEmployees()).thenReturn(employees);
		  
		  
		  
		  assertEquals(3,service.getEmployeesBasedOnSalary(20000).size());
		
	}

	
	
}
