package com.training.emp.service;
import java.util.Comparator;

import com.training.emp.model.PermanentEmployee;

public class SalaryComparator implements Comparator<PermanentEmployee>{

	
	public int compare(PermanentEmployee one, PermanentEmployee two) {
		// TODO Auto-generated method stub
		return (int) (one.getBasicSalary()-two.getBasicSalary());
	}

}
