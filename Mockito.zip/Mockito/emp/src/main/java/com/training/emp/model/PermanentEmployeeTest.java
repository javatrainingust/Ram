package com.training.emp.model;

import static org.junit.Assert.*;

import org.junit.Test;

public class PermanentEmployeeTest {

	@Test
	public void testDoPerformanceAppraisal() {
		
		int expectedValue = 3;
		
		PermanentEmployee pe = new PermanentEmployee();
		
		pe.doPerformanceAppraisal("good");
		
		int actualValue =pe.getRating();
		
		assertEquals(expectedValue,actualValue);
		
		
	}

}
