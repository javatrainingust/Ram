package com.training.emp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.emp.model.PermanentEmployee;
import com.training.emp.service.PermanentEmployeeService;

@RestController
public class PermanentEmployeeController {
	
	@Autowired
	private PermanentEmployeeService service;
	
	
	
	@PostMapping("/employees") 
	public PermanentEmployee addEmployee(@RequestBody  PermanentEmployee pe) {
		
		
		service.addPermanentEmployee(pe);
		
		return pe;
		
		
	}
	
	@GetMapping("/employees-salaries/{basic}") 
	public List<PermanentEmployee> getEmployeesBasedOnSalary(@PathVariable float basic){
		
		
		List<PermanentEmployee> employeeList = service.getEmployeesBasedOnSalary(basic);
		
				
		return employeeList;
		
	}
	
	@PutMapping("/employees/{id}")
	public PermanentEmployee updateEmployee(@PathVariable int id,@RequestBody PermanentEmployee pe) {
		
		PermanentEmployee oldPE =service.getPermanentEmployeeByEmployeeId(id);
		
		if(oldPE!=null) {
			
			service.updatePermanentEmployee(pe);
		}
		
		
		return pe;
		
		
	}
	
	
	
	@GetMapping("/employees") 
	public List<PermanentEmployee> getAllEmployees(){
		
		
		List<PermanentEmployee> employeeList = service.getAllPermanentEmployees();
		
		return employeeList;
		
	}
	
	@RequestMapping("/sortEmployeesByName")
	
	public String getAllEmployeesSortByName(Model model){
	System.out.println("Inside controller getAllEmployeesSortByName");
		
		List<PermanentEmployee> employeeList = service.getAllPermanentEmployeesSortedByNames();
		
		model.addAttribute("employees",employeeList );
		
		
		return "permanentEmployeeList";
		
	}
	@RequestMapping("/sortEmployeesBySalary")	
	public String getAllEmployeesSortBySalary(Model model){
	System.out.println("Inside controller getAllEmployeesSortByName");
		
		List<PermanentEmployee> employeeList = service.getAllPermanentEmployeesSortedByBasicSalary();
		
		model.addAttribute("employees",employeeList );
		
		
		return "permanentEmployeeList";
		
	}
	
	@GetMapping("/employees/{id}") 
	public PermanentEmployee getEmployee(@PathVariable int id) {
		
		
		PermanentEmployee pe = service.getPermanentEmployeeByEmployeeId(id);
		
		return pe;
		
		
	}
	
	@DeleteMapping("/employees/{id}") 
	public void deleteEmployee(@PathVariable int id) {
		
		
		service.deletePermanentEmployee(id);		
				
		
		
		
	}

}
