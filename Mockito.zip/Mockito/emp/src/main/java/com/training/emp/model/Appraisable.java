package com.training.emp.model;

public interface Appraisable {
	
	public void doPerformanceAppraisal(String feedback);

}
