package com.training.emp.util;

public interface CalculatorSalary {
	
	public float calculateSalary(int lossOfPay,float basic);
	
	public float calculateSalary (int lossOfPay, float dailyRate, int contractPeriodInDays);

}
