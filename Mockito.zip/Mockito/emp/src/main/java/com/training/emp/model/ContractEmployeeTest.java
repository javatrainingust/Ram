package com.training.emp.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ContractEmployeeTest {

	@Test
	public void test() {
		
		boolean expectedValue = true;
		
		ContractEmployee ce  = new ContractEmployee();
		
		ce.renewContract("excellent");
		
		boolean actualValue = ce.isRenew();
		
		assertEquals(expectedValue,actualValue);
		
	}

}
