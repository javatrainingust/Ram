package com.training.emp.repository;

import com.training.emp.model.ContractEmployee;
import com.training.emp.model.Employee;
import com.training.emp.model.PermanentEmployee;

public class EmployeeRepository {
	
	
	public static Employee getPermanentEmployee(){
		
		PermanentEmployee pe = new PermanentEmployee();
		
		return pe;
	}

	
	public static Employee  getContractEmployee(){
		
		ContractEmployee ce = new ContractEmployee();
		
		return ce;
	}
}
