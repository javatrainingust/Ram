package com.ust.training;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Restaurant {
	
	
	List<GroceriesShop> groceries;
	
	public List<GroceriesShop> getGroceries() {
		return groceries;
	}




	public void setGroceries(List<GroceriesShop> groceries) {
		this.groceries = groceries;
	}




	public Set<VegetableShop> getVegetableshops() {
		return vegetableshops;
	}




	public void setVegetableshops(Set<VegetableShop> vegetableshops) {
		this.vegetableshops = vegetableshops;
	}




	Set<VegetableShop> vegetableshops;
	
	Map delivaryBoysMap;
	
	



	public Map getDelivaryBoysMap() {
		return delivaryBoysMap;
	}




	public void setDelivaryBoysMap(Map delivaryBoysMap) {
		this.delivaryBoysMap = delivaryBoysMap;
	}




	public Restaurant() {
		
		System.out.println("inside default constructor of Restaurant");
	}
	
	
	
	
	public void prepareMeal() {
		
		for(GroceriesShop g: groceries) {
			
			g.supplyGroceries();
			
		}
		
		Iterator it = vegetableshops.iterator(); 
		
		while(it.hasNext())  
		{  
		
			VegetableShop vegetableShop = (VegetableShop) it.next();
		
			vegetableShop.supplyVegetables();
		
		}  
		
		System.out.println("Meals is prepared");
	}
	
	
	public void serveMeal() {
		
		prepareMeal();
		System.out.println("Meal is served");
		
	}




	



	




	



	
	
	
	
	
}
