package com.ust.training;

public class DelivaryBoy {
	
	String name;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public DelivaryBoy() {
		
		
		
		System.out.println("inside default constructor of DelivaryBoy");
	}
	
	public void deliverOrder() {
		
		System.out.println("Order is delivered at customer doorsteps by "+this.getName());
	}

}
