package com.training.lms.service;

import com.training.exception.InsufficientLeavelBalanceException;
import com.training.model.ContractEmployee;
import com.training.model.Employee;
import com.training.model.PermanentEmployee;

public class LeaveService {
	
	
	public static void main(String arg[]){
		
		
		PermanentEmployee pe = new PermanentEmployee();
		
		pe.setEmployeeId(1000);
		pe.setName("Kumar");
		pe.setDesignation("Developer");
		pe.doPerformanceAppraisal("Excellent");
		
		
		
		try{
			
			pe.applyLeave(21);
			
				
			
		}
		catch(InsufficientLeavelBalanceException e){
			
			System.out.println("You have "+pe.getLeaves()+" days leaves "+e);
			
		}
		
		//ContractEmployee ce = new ContractEmployee();
		
		//ce.setContractPeriodInDays(60);
		//ce.setName("Ravi");
		//ce.setEmployeeId(3000);
		//ce.setDailyRate(5000);
		
		//ce.updateRenewal("Excellent");
		
		
		
		
		
		
		
	}

}
