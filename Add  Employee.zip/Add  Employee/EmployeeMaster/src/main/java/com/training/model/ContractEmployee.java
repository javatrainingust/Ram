package com.training.model;

import java.io.FileNotFoundException;

import com.training.util.SalaryCalculator;

public class ContractEmployee extends Employee{
	
	private int contractPeriodInDays;
	
	private float dailyRate;
	
	public ContractEmployee(){
		
		
	}
	
	public ContractEmployee(int id, String name,int contractPeriodInDays, float dailyRate) {
		super(id,name);
		this.contractPeriodInDays = contractPeriodInDays;
		this.dailyRate = dailyRate;
	}

	public int getContractPeriodInDays() {
		return contractPeriodInDays;
	}

	public void setContractPeriodInDays(int contractPeriodInDays) {
		this.contractPeriodInDays = contractPeriodInDays;
	}

	private SalaryCalculator calculator = new SalaryCalculator();
	
	public float getDailyRate() {
		return dailyRate;
	}

	public void setDailyRate(float dailyRate) {
		this.dailyRate = dailyRate;
	}

	private boolean isRenew;
	
	public boolean isRenew() {
		return isRenew;
	}

	public void renewContract(String feedback){
		
		
		if(feedback.equals("excellent") || feedback.equals("better")){
			
			this.isRenew = true;
		}
		
		
	}
	
	public void calculateSalary(int lossOfPay) {
		
		System.out.println("inside Contract employee class");
		
		this.takeHomeSalary =calculator.calculateSalary(lossOfPay, dailyRate, contractPeriodInDays);
		
		System.out.println("Take home salary "+this.takeHomeSalary)	;		
		
	}

}
