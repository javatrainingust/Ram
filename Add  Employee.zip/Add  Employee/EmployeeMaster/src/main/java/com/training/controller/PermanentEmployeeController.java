package com.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.model.PermanentEmployee;
import com.training.service.PermanentEmployeeService;

@Controller
public class PermanentEmployeeController {
	
	@Autowired
	private PermanentEmployeeService service;
	
	
	@RequestMapping("/showEmployeeform")
	
	public String showEmployeeForm(Model model) {
		
		PermanentEmployee pe = new PermanentEmployee();
		
		model.addAttribute("key", pe);
		return "addEmployee";
		
		
	}
	
	@RequestMapping("/addEmployee")
	public String addEmployee(@ModelAttribute("permanentEmployee") PermanentEmployee pe) {
		
		
		service.addPermanentEmployee(pe);
		
		return "redirect:/employees";
		
		
	}
	
	
	@RequestMapping("/employees")
	
	public String getAllEmployees(Model model){
		
		System.out.println("Inside controller getAllEmployees");
		List<PermanentEmployee> employeeList = service.getAllPermanentEmployees();
		
		model.addAttribute("employees",employeeList );
		
		
		return "permanentEmployeeList";
		
	}
		
	@RequestMapping("/viewEmployee")
	public String getEmployee(@RequestParam("id")String id,Model model) {
		
		
		PermanentEmployee pe = service.getPermanentEmployeeByEmployeeId(Integer.parseInt(id));
		
		model.addAttribute("key", pe);
		
		
		return "viewEmployee";
		
		
	}
	
	@RequestMapping("/deleteEmployee")
	public String deleteEmployee(@RequestParam("id")String id,Model model) {
		
		
		service.deletePermanentEmployee(Integer.parseInt(id));
		
				
		return "redirect:/employees";
		
		
	}

}
