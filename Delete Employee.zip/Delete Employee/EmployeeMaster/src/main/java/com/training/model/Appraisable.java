package com.training.model;

public interface Appraisable {
	
	public void doPerformanceAppraisal(String feedback);

}
