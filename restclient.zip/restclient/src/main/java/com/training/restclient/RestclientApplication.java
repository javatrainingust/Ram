package com.training.restclient;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.training.restclient.model.PermanentEmployee;
import com.training.restclient.model.Employee;

@SpringBootApplication
public class RestclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestclientApplication.class, args);
		
		//getResource();
		
		//postResource();
		
		//putResource();
		
		deleteResource();
		
		getAllResources();
		
		
	}
	
	
	public static void  getResource() {
		
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8000/emp/employees/{id}";
	    	     
	    Map<String, Integer> params = new HashMap<String, Integer>();
	    params.put("id", 5000);
	     
	    PermanentEmployee result = restTemplate.getForObject(uri, PermanentEmployee.class, params);
	    
	    System.out.println("Employee name: "+result.getName());
	    System.out.println("Employee Designation: "+result.getDesignation());
	    System.out.println("Employee Basic salary: "+result.getBasicSalary());
		
		
	}
	
	
	public static void getAllResources() {
		
		System.out.println("Inside getAllResources() method");
	
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8000/emp/employees";
	    	     
	    	     
	    ResponseEntity<PermanentEmployee[]> response  = restTemplate.getForEntity(uri, PermanentEmployee[].class);
	    
	    PermanentEmployee[] employees = response.getBody();

	    
	    for(int i=0; i<employees.length;i++) {
	    	
	    	PermanentEmployee pe= (PermanentEmployee)employees[i];	    
	    System.out.println("Employee name: "+pe.getName());
	    System.out.println("Employee designation: "+pe.getDesignation());
	    System.out.println("Employee basic salary: "+pe.getBasicSalary());
	    
	    }
		
		
		
	}
	
	public static void postResource() {
		
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8000/emp/employees";
	
		PermanentEmployee pe = new PermanentEmployee(5004,"Mohan", "Project Lead",80000);
	
		PermanentEmployee result = restTemplate.postForObject( uri, pe, PermanentEmployee.class);
		
		
	}
	
	
	public static void putResource() {
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8000/emp/employees/{id}";
	    	     
	    Map<String, Integer> params = new HashMap<String, Integer>();
	    params.put("id", 5004);
	     
	    PermanentEmployee updatedEmployee = new PermanentEmployee(5004,"Mohan Kumar", "Project Lead",60000);
	    
	     restTemplate.put(uri, updatedEmployee, params);
		
		
		
		
	}
	
	public static void deleteResource() {
		
		RestTemplate restTemplate = new RestTemplate();
		
		final String uri = "http://localhost:8000/emp/employees/{id}";
	    	     
	    Map<String, Integer> params = new HashMap<String, Integer>();
	    params.put("id", 5004);
	     
	     restTemplate.delete(uri, params);
	}

}
