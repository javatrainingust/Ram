package com.payrol.service;

import com.training.model.ContractEmployee;
import com.training.model.PermanentEmployee;

import com.training.util.CalculatorSalary;

import com.training.util.SalaryCalculator;

public class PayrolService {
	
	public static void main(String arg[]){
		
		
		PermanentEmployee pe = new PermanentEmployee();
		
		pe.setEmployeeId(1000);
		pe.setName("Kumar");
		pe.setBasicSalary(50000);
		pe.setDesignation("Developer");
		
		//pe.updateLeave(2);
		
		pe.doPerformanceAppraisal("Better");
		
		
		SalaryCalculator calculator = new SalaryCalculator();
		
		//NewSalaryCalculator calculator =new NewSalaryCalculator();
		
		
		
		pe.calculateSalary(1,calculator);
		
		ContractEmployee ce = new ContractEmployee();
		
		ce.setEmployeeId(5000);
		ce.setName("Ravi");
		ce.setDailyRate(5000);
		ce.setContractPeriodInDays(22);
		
		//ce.updateLeave(2);
		//ce.renewContract("Excellent");	
		
		
		
		ce.calculateSalary(1);
		
		
	}
	

}
