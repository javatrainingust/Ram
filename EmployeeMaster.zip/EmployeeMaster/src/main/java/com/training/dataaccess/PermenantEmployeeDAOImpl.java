package com.training.dataaccess;

import com.training.model.PermanentEmployee;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Repository;

import com.training.model.PermanentEmployee;

@Repository
public class PermenantEmployeeDAOImpl implements PermanentEmployeeDAO {
	
	List permanentEmployeeList;
	
	private Set permanentEmployeeSet;
	
	public PermenantEmployeeDAOImpl(){
		
		permanentEmployeeList = new ArrayList<PermanentEmployee>();
		
		permanentEmployeeSet = new HashSet<PermanentEmployee>();
		
		PermanentEmployee pe1 = new PermanentEmployee(1000,"Ram", "Developer",50000);
		
		PermanentEmployee pe2 = new PermanentEmployee(1001,"Vivek", "Tech Lead",70000);
		
		PermanentEmployee pe3 = new PermanentEmployee(1002,"Komal", "Manager",80000);
		
		PermanentEmployee pe4 = new PermanentEmployee(1003,"Anish", "Analyst",60000);
		
		PermanentEmployee pe5 = new PermanentEmployee(1004,"John", "Tester",40000);
		
		permanentEmployeeList.add(pe1);
		permanentEmployeeList.add(pe2);
		permanentEmployeeList.add(pe3);
		permanentEmployeeList.add(pe4);
		permanentEmployeeList.add(pe5);
		
	}
		
	

	
	public List<PermanentEmployee> getAllPermanentEmployees() {
		
		System.out.println("Inside DAOImpl");
		
		return permanentEmployeeList;
	}

	
	public PermanentEmployee getPermanentEmployeeByEmployeeId(int employeeId) {
		// TODO Auto-generated method stub
		PermanentEmployee permanentEmployee=null;
		
		Iterator<PermanentEmployee> iterator = permanentEmployeeList.iterator();
		
		while(iterator.hasNext()){
			
			PermanentEmployee pe = iterator.next();
			
			if(pe.getEmployeeId()==employeeId){
				
				permanentEmployee=pe;
			}
			
			
		}
			
		
		return permanentEmployee;
	}

	
	public void deletePermanentEmployee(int employeeId) {
		
		
		
		PermanentEmployee permanentEmployee = null;
		
		for(int i=0; i<permanentEmployeeList.size(); i++){
			
			permanentEmployee =(PermanentEmployee) permanentEmployeeList.get(i);
			
			if(permanentEmployee.getEmployeeId()==employeeId){
				
				permanentEmployeeList.remove(i);
				
			}
			
		}		
		
		

	}

	
	public boolean addPermanentEmployee(PermanentEmployee permanentEmployee) {
		
		boolean isAdded =  permanentEmployeeSet.add(permanentEmployee);
		
		if(isAdded){
			permanentEmployeeList.add(permanentEmployee);
			 
		}
		return isAdded;
		
	}

	
	public void updatePermanentEmployee(PermanentEmployee permanentEmployee) {
		
		Iterator iterator = permanentEmployeeList.iterator();
		
		
		while(iterator.hasNext()){
			
			PermanentEmployee pe =(PermanentEmployee)iterator.next();
			
			if(pe.getEmployeeId()==permanentEmployee.getEmployeeId()){
				
				pe.setName(permanentEmployee.getName());
				pe.setDesignation(permanentEmployee.getDesignation());
				pe.setBasicSalary(permanentEmployee.getBasicSalary());
				
			}
			
			
		}
	}

}
