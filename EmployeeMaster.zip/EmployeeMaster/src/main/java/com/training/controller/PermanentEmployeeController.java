package com.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.training.model.PermanentEmployee;
import com.training.service.PermanentEmployeeService;

@RestController
public class PermanentEmployeeController {
	
	@Autowired
	private PermanentEmployeeService service;
	
	
	
	@RequestMapping(value="/employees",method=RequestMethod.POST) 
	public PermanentEmployee addEmployee(@RequestBody  PermanentEmployee pe) {
		
		
		service.addPermanentEmployee(pe);
		
		return pe;
		
		
	}
	
	@RequestMapping(value="/employees/{id}",method=RequestMethod.PUT)
	public PermanentEmployee updateEmployee(@PathVariable int id,@RequestBody PermanentEmployee pe) {
		
		PermanentEmployee oldPE =service.getPermanentEmployeeByEmployeeId(id);
		
		if(oldPE!=null) {
			
			service.updatePermanentEmployee(pe);
		}
		
		
		return pe;
		
		
	}
	
	
	
	@RequestMapping(value="/employees",method=RequestMethod.GET) 
	public List<PermanentEmployee> getAllEmployees(){
		
		
		List<PermanentEmployee> employeeList = service.getAllPermanentEmployees();
		
		return employeeList;
		
	}
	
	@RequestMapping("/sortEmployeesByName")
	
	public String getAllEmployeesSortByName(Model model){
	System.out.println("Inside controller getAllEmployeesSortByName");
		
		List<PermanentEmployee> employeeList = service.getAllPermanentEmployeesSortedByNames();
		
		model.addAttribute("employees",employeeList );
		
		
		return "permanentEmployeeList";
		
	}
	@RequestMapping("/sortEmployeesBySalary")	
	public String getAllEmployeesSortBySalary(Model model){
	System.out.println("Inside controller getAllEmployeesSortByName");
		
		List<PermanentEmployee> employeeList = service.getAllPermanentEmployeesSortedByBasicSalary();
		
		model.addAttribute("employees",employeeList );
		
		
		return "permanentEmployeeList";
		
	}
	
	@RequestMapping(value="/employees/{id}",method=RequestMethod.GET) 
	public PermanentEmployee getEmployee(@PathVariable int id) {
		
		
		PermanentEmployee pe = service.getPermanentEmployeeByEmployeeId(id);
		
		return pe;
		
		
	}
	
	@RequestMapping(value="/employees/{id}",method=RequestMethod.DELETE) 
	public void deleteEmployee(@PathVariable int id) {
		
		
		service.deletePermanentEmployee(id);		
				
		
		
		
	}

}
