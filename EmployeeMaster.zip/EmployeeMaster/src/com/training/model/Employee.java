package com.training.model;

import java.io.FileNotFoundException;

import com.training.util.CalculatorSalary;
import com.training.util.NewSalaryCalculator;
import com.training.util.SalaryCalculator;

public class Employee {
	
	private int employeeId;
	
	private String name;
	
	private int leaves=20;
		
	protected float  takeHomeSalary;
	
	
	public float getTakeHomeSalary() {
		return takeHomeSalary;
	}



	public void setTakeHomeSalary(float takeHomeSalary) {
		this.takeHomeSalary = takeHomeSalary;
	}



	public int getEmployeeId() {
		return employeeId;
	}



	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	



	


	public int getLeaves() {
		return leaves;
	}



	public void updateLeave(int leaveTaken){
		
		this.leaves = this.leaves-leaveTaken;
		
		System.out.println("Availabe leaves "+ this.leaves);
		
		
	}
	
	public  void  calculateSalary(int lossOfPay,CalculatorSalary calculator) {
		
		System.out.println("inside employee class");
		
		
	}

}
