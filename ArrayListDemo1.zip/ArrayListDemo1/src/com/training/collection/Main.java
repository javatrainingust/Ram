package com.training.collection;

public class Main{
	
	public static void main(String arg[]) {
		
		int carSales[] = new int[5];
		
		carSales[0] = 1000;
		carSales[1] = 500;
		carSales[2] = 700;
		carSales[3] = 1200;
		carSales[4] = 400;
		carSales[5] = 300;
		
		
		for (int i:carSales) {
			
			System.out.println("No of cars sold: "+i);
		}
		
		
		
	}

}


