package com.training.CosmosDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CosmosDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
