package com.training.collection;

import java.util.HashSet;
import java.util.Set;

public class SetDemo {
	
	
	public static void main(String arg[]) {
		
		
		boolean[] b =new boolean[3];
		
		Set s = new HashSet();
		
		b[0] = s.add("a");
		
		b[1] = s.add("b");
		
		b[2] = s.add("a");
		
		for (int i=0; i<b.length; i++) {
			
			System.out.println("Value inside boolean array:"+b[i]);
		}
	
	for(Object o:s) {
		
		System.out.println("Value inside Set:"+o);
	}

}
}
