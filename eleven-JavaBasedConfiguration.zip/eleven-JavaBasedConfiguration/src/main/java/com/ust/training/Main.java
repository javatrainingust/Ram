package com.ust.training;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;


public class Main {
	
	public static void main(String arg[]) {
		
		
		// loading the definitions from the given XML file
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(springConfig.class);
		 
		Restaurant restaurant =  context.getBean("saravanabhavan",Restaurant.class);
		
		restaurant.serveMeal();
		
		
	}

}
