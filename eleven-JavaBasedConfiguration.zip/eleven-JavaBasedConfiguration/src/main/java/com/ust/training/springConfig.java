package com.ust.training;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class springConfig {
	
	
	@Bean(name = "saravanabhavan")
	public Restaurant getRestaurant() {
		
		System.out.println("inside getRestaurant() method of SpringConfig class");
		
		Restaurant restaurant = new Restaurant();
		
		
		restaurant.setGopalProvisionsStore(getGroceriesShop());
		
		restaurant.setMuruganVegetableMart(getVegetableShop());
		
		return restaurant;
	}

	@Bean()
	public  VegetableShop getVegetableShop() {
		// TODO Auto-generated method stub
		System.out.println("inside getVegetableShop() method of SpringConfig class");
		VegetableShop vegetableShop = new VegetableShop();
		return vegetableShop;
	}

	@Bean()
	public  GroceriesShop getGroceriesShop() {
		System.out.println("inside getGroceriesShop() method of SpringConfig class");
		GroceriesShop groceriesShop = new GroceriesShop();
		return groceriesShop;
	}

}
