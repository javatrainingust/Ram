package com.training.CosmosDemo1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CosmosDemo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
