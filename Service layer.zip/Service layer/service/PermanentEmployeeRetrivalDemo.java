package com.training.service;

public class PermanentEmployeeRetrivalDemo {
	
	
	public static void main(String arg[]){
		
		
		PermanentEmployeeService service =  new PermanentEmployeeService();
		
		
		//retrieving all employees
		
		service.getAllPermanentEmployees();
		
		System.out.println("----------------------------------");
		
		
		service.getPermanentEmployeeByEmployeeId(1002);
		
		
		
		
	}

}
